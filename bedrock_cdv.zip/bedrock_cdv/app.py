import boto3
import json
from chalice import Chalice, Response
from botocore.config import Config
from langchain.llms.bedrock import Bedrock
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from chalicelib.helper import create_index, get_index_data

app = Chalice(app_name='bedrock_new')


@app.route('/', cors=True)
def index():
    return {'hello': 'world'}


@app.route('/bedrock', cors=True)
def get_data():
    request = app.current_request
    prompts = request.query_params.get("question") if request.query_params else None
    config = Config(
        read_timeout=120,
        retries=dict(
            max_attempts=5
        )
    )
    bedrock_runtime = boto3.client(service_name='bedrock-runtime', region_name='us-east-1', config=config)

    # prompts = "How to change a flat tire"

    # create the Langchain Bedrock Client
    inference_modifier = {'max_tokens_to_sample': 100,
                          "temperature": 0.1,
                          "top_k": 250,
                          "top_p": 1,
                          }
    llm = Bedrock(model_id='anthropic.claude-v2', client=bedrock_runtime, model_kwargs=inference_modifier,
                  streaming=True,  # Toggle this to turn streaming on or off
                  callbacks=[StreamingStdOutCallbackHandler()])

    response = llm(prompts)
    return Response(body= response,
             status_code=200,
             headers={'Content-Type': 'text/plain'})


@app.route('/create_index')
def create_upload_index():
    request = app.current_request
    key = request.query_params.get("key") if request.query_params else None
    index = request.query_params.get("index") if request.query_params else None
    resp = create_index(key, index)
    print(resp)
    return Response(body={"status": "success"},
                    status_code=200,
                    headers={'Content-Type': 'text/json'}
                    )


@app.route('/get_data', cors=True)
def create_upload_index():
    request = app.current_request
    user = request.query_params.get("user") if request.query_params else None
    question = request.query_params.get("question") if request.query_params else None
    index_name = request.query_params.get("app") if request.query_params else None
    return get_index_data(user, question, index_name)

